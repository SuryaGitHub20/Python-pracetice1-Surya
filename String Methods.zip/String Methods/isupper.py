a=""
print(a.isupper())

a=" =123"
print(a.isupper())

a="_USER_123"
print(a.isupper())

a="homer"
print(a.isupper())

a="HOMER"
print(a.isupper())

a="Homer"
print(a.isupper())

a="HOMER"
a=a.casefold()
print(a.isupper())
