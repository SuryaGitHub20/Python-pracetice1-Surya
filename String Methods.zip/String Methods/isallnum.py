c="Fitness"
print(c.isalnum())

c="123"
print(c.isalnum())

c="1.23"
print(c.isalnum())

c="surya"
print(c.isalnum())

c="$@!!!"
print(c.isalnum())
