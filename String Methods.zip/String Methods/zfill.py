a="12"
print(a.zfill(4))

a="-23"
print(a.zfill(4))

a="+32"
print(a.zfill(4))
