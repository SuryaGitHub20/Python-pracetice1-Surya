a="Surya bag.Surya phone.Surya watch"
print(a.replace("Surya","Pandu"))
print(a.replace("Surya","Pandu",2))
