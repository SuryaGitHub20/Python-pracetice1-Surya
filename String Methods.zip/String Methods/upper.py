a="bee"
print(a.upper())
