c="Fitness"
print(c.isalpha())

c="123"
print(c.isalpha())

c="$*%!!"
print(c.isalpha())
