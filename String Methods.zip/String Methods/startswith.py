a="Surya"
print(a.startswith("S"))
print(a.startswith("s"))
print(a.startswith("Surya"))
print(a.startswith("z"))
print(a.startswith("ry",2,5))
