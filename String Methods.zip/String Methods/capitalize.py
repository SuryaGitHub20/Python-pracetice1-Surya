a="surya"
print(a.capitalize())
