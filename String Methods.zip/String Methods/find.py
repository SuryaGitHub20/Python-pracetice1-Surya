a="Surya"
print(a.find("S"))
print(a.find("s"))
print(a.find("h"))
print(a.find("rya"))
print(a.find("a"))
