a="string-method"
print(a.partition("-"))
print(a.partition("."))

