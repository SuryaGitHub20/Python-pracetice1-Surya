a="Surya kumar"
print(a.rindex("S"))
print(a.rindex("r"))
print(a.rindex("a"))
print(a.rindex("p"))
print(a.rindex("z"))
