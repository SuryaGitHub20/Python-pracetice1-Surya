a="-"
print(a.join("123"))

a="."
print(a.join("USA"))

a=". "
print(a.join(("Dr", "Who")))
