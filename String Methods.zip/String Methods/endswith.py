a="Banana"
print(a.endswith("a"))
print(a.endswith("nana"))
print(a.endswith("s"))
print(a.endswith("an",1,3))
