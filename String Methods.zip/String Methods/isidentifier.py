a="123"
print(a.isidentifier())

a="_user_123"
print(a.isidentifier())

a="_user-123"
print(a.isidentifier())

a="Homer"
print(a.isidentifier())

a="for"
print(a.isidentifier())


