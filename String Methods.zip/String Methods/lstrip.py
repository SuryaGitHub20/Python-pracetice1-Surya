a="    bee    "
print(a.lstrip(),"!")

a="-----bee------"
print(a.lstrip())
