a=""
print(a.isspace())

a=" "
print(a.isspace())

a=u"\u00B2"
print(a.isspace())

a="Bart"
print(a.isspace())

a="\t"
print(a.isspace())

a="\r\n"
print(a.isspace())

a="Bart \r"
print(a.isspace())
