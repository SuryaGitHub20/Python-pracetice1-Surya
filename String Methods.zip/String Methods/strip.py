a="    bee    "
print(a.strip(),"!")

a="-----bee-----"
print(a.strip("-"))
