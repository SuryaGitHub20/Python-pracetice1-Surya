a="Fitness"
print(a.index("F"))
print(a.index("t"))
print(a.index("ness"))
print(a.index("n"))
print(a.index("z")) #Error
