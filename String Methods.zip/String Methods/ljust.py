a="bee"
b=a.ljust(12,"-")
print(b)
