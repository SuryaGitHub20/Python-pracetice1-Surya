a="     bee     "
print(a.rstrip(),"!")

a="------bee-----"
print(a.rstrip("-"))

