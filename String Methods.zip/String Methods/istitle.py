a=""
print(a.istitle())

a=" "
print(a.istitle())

a="t"
print(a.istitle())

a="T"
print(a.istitle())

a="Tea"
print(a.istitle())

a="Tea and Coffee"
print(a.istitle())

a="Tea And Coffee"
print(a.istitle())
a="1.Tea & Coffee \r"
print(a.istitle())

