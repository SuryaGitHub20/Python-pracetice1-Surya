a="BEE"
print(a.lower())
