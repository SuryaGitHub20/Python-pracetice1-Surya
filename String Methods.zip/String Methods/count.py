a="mushrooom soup"
print(a.count("0"))
print(a.count("o"))
print(a.count("oo"))
print(a.count("ooo"))
print(a.count("soup"))
print(a.count("o",3,7))
print(a.count("oo",6))
