a=" "
print(a.islower())

a="123"
print(a.islower())

a="_user_123"
print(a.islower())

a="Homer"
print(a.islower())

a="homer"
print(a.islower())

a="HOMER"
a=a.casefold()#force lowercase
print(a.islower())
