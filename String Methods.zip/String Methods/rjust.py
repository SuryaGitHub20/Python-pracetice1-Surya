a="bee"
print(a.rjust(12,"-"))
