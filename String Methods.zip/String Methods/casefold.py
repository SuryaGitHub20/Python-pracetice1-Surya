a="SURYA"
print(a.casefold())
