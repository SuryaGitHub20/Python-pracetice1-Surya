c="123"
print(c.isdecimal())

c="Fitness"
print(c.isdecimal())

c="u\u00B2"
print(c.isdecimal())

c="1.23"
print(c.isdecimal())

c="$*%!!"
print(c.isdecimal())
