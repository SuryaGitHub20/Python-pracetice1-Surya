a="surya"
b=a.center(10,"-")
print(b)
