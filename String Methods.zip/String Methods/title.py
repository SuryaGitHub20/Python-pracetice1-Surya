a="surya"
print(a.title())
