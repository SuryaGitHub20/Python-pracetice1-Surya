a="Python Program"
print(a.swapcase())
