a="Surya kumar"
print(a.rfind("S"))
print(a.rfind("r"))
print(a.rfind("a"))
print(a.rfind("p"))
print(a.rfind("z"))
